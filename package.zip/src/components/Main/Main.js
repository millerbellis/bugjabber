import React, { Component } from 'react';
import { NavLink, Form,Modal, ModalHeader, ModalBody, ModalFooter,Button,Collapse, Navbar, NavbarToggler, NavbarBrand, Nav, NavItem, NavLinkForm, FormGroup, Label, Input, FormText } from 'reactstrap';
import Register from '../Auth/Register';
import Login from '../Auth/Login';
import firebase from '../../firebase';
import Info from '../Info/info';
class Main extends Component {
    
    constructor(props) {
        super(props);
    
        this.toggleNavbar = this.toggleNavbar.bind(this);
        this.state = {
          collapsed: true,
          modal: false,
          modal1: false,
          username: '',
          password: '',
          email: '',
          user: this.props.currentUser
        };
        this.toggle = this.toggle.bind(this);
        this.toggle1 = this.toggle1.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
      }
      
    
      toggleNavbar() {
        this.setState({
          collapsed: !this.state.collapsed
        });
      }
      toggle() {
        this.setState({
          modal: !this.state.modal
        });
      }
      toggle1() {
        this.setState({
          modal1: !this.state.modal1
        });
      }
      handleChange(event) {
        this.setState({
          username: event.target.username,
          email: event.target.email
        });
      }
      handleSubmit(event) {
        
        event.preventDefault();
        this.setState({
          username: event.target.username,
          email: event.target.email
        });
        alert('A name was submitted: ' + this.state.username);
      }
  render() {
    return (

        <React.Fragment>
        <div>
       <Navbar color="dark" dark style={{boxShadow: '0px 5px 4px'}}>
          <NavbarBrand href="/" className="mr-auto" >BugJabber</NavbarBrand>
         
          <NavbarBrand><Button color='primary' onClick={this.toggle1}>Login</Button></NavbarBrand>
          <NavbarBrand><Button color='primary' onClick={this.toggle}>Sign up</Button></NavbarBrand>
    
        </Navbar>

        
      </div>
<Info />
<Modal isOpen={this.state.modal} toggle={this.toggle} className={this.props.className} style={{boxShadow: '0px 5px 4px'}}>
<ModalHeader toggle={this.toggle}>Signup</ModalHeader>

<ModalBody>
<Register/>


</ModalBody>
<ModalFooter>
</ModalFooter>

</Modal>

<Modal isOpen={this.state.modal1} toggle={this.toggle1} className={this.props.className} style={{boxShadow: '0px 5px 4px'}}>
<ModalHeader toggle={this.toggle1}>Login</ModalHeader>

<ModalBody>
<Login/>


</ModalBody>
<ModalFooter>
</ModalFooter>

</Modal>
   </React.Fragment>
    
    );
  }
}

export default Main;
