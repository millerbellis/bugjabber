import React, { Component } from 'react';
import { NavLink, Form,Modal, ModalHeader, ModalBody, ModalFooter,Button,Collapse, Navbar, NavbarToggler, NavbarBrand, Nav, NavItem, NavLinkForm, FormGroup, Label, Input, FormText } from 'reactstrap';
import Register from '../Auth/Register';
import firebase from '../../firebase';
import SideBar from '../SidePanel/SidePanel';
import Messages from '../Messages/Messages';
class Main extends Component {
    
    constructor(props) {
        super(props);
    
        this.toggleNavbar = this.toggleNavbar.bind(this);
        this.state = {
          collapsed: true,
          modal: false,
          username: '',
          password: '',
          email: '',
          user: this.props.currentUser,
          currentChannel: this.props.currentChannel,
          isPrivateChannel: this.props.isPrivateChannel
        };
        this.toggle = this.toggle.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
      }
      
    
      toggleNavbar() {
        this.setState({
          collapsed: !this.state.collapsed
        });
      }
      toggle() {
        this.setState({
          modal: !this.state.modal
        });
      }
      handleChange(event) {
        this.setState({
          username: event.target.username,
          email: event.target.email
        });
      }
      handleSubmit(event) {
        
        event.preventDefault();
        this.setState({
          username: event.target.username,
          email: event.target.email
        });
        alert('A name was submitted: ' + this.state.username);
      }
      handleSignout = () => {
        firebase
          .auth()
          .signOut()
          .then(() => console.log("signed out!"));
      };
  render() {
    const { currentUser } = this.props;
    return (
      <React.Fragment>
        <div>
       <Navbar color="dark" dark style={{boxShadow: '0px 5px 4px'}}>
          <NavbarBrand href="/" className="mr-auto">BugJabber</NavbarBrand>
         
          <NavbarBrand><Button color='primary' onClick={this.toggle}> Signed in as <strong>{this.state.user.displayName}</strong></Button></NavbarBrand>
      

          
          <NavbarToggler onClick={this.toggleNavbar} className="mr-2" />
          <Collapse isOpen={!this.state.collapsed} navbar>
            <Nav navbar>
              <NavItem>
               <SideBar key={this.state.currentUser && this.state.currentUser.uid} currentUser={this.state.user}/>
              </NavItem>
            </Nav>
          </Collapse>
        </Navbar>

        
      </div>

<Modal isOpen={this.state.modal} toggle={this.toggle} className={this.props.className} style={{boxShadow: '0px 5px 4px'}}>
<ModalHeader toggle={this.toggle}>Signup</ModalHeader>

<ModalBody>



</ModalBody>
<ModalFooter>
</ModalFooter>

</Modal>
   </React.Fragment>
    
    );
  }
}

export default Main;
