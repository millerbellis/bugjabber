import React, { Component } from 'react';
import { Card, CardBody, CardTitle, CardSubtitle, CardText,Jumbotron, NavLink, Form,Modal, ModalHeader, ModalBody, ModalFooter,Button,Collapse, Navbar, NavbarToggler, NavbarBrand, Nav, NavItem, NavLinkForm, FormGroup, Label, Input, FormText } from 'reactstrap';
import Register from '../Auth/Register';
import Login from '../Auth/Login';
import firebase from '../../firebase';
class Main extends Component {
    
    constructor(props) {
        super(props);
    
        this.toggleNavbar = this.toggleNavbar.bind(this);
        this.state = {
          collapsed: true,
          modal: false,
          modal1: false,
          username: '',
          password: '',
          email: '',
          user: this.props.currentUser
        };
        this.toggle = this.toggle.bind(this);
        this.toggle1 = this.toggle1.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
      }
      
    
      toggleNavbar() {
        this.setState({
          collapsed: !this.state.collapsed
        });
      }
      toggle() {
        this.setState({
          modal: !this.state.modal
        });
      }
      toggle1() {
        this.setState({
          modal1: !this.state.modal1
        });
      }
      handleChange(event) {
        this.setState({
          username: event.target.username,
          email: event.target.email
        });
      }
      handleSubmit(event) {
        
        event.preventDefault();
        this.setState({
          username: event.target.username,
          email: event.target.email
        });
        alert('A name was submitted: ' + this.state.username);
      }
  render() {
    return (

        <React.Fragment>
    <div>
      <Jumbotron style={{boxShadow: '0px 5px 4px'}}>
        <h1 className="display-3">Hello, future BugJabbers!</h1>
        <p className="lead">This is solely used for day-to-day communications for companies! Just like slack but without the advertisments!</p>
        <hr className="my-2" />
        <p>Bugjabber is solely here for better communication for companies of any size! We have direct messaging, open communication and fun! Contact us to have your own version of bugjabber today! Just message the admin!</p>
        <p className="lead">
        <Button color='primary' style={{boxShadow: '0px 5px 4px'}} outline onClick={this.toggle}>Sign up</Button>
        </p>
      </Jumbotron>
    </div>
    <div>
      <Card>
      
        <CardBody style={{boxShadow: '0px 5px 4px'}}>
          <CardTitle>Judge Free Zone!</CardTitle>
          <CardSubtitle>Talk about anything!</CardSubtitle>
          <CardText>We regulate messages to ensure that no one is harrased or hurt by others!</CardText>
         
        </CardBody>
      </Card>
      <Card>
      
        <CardBody style={{boxShadow: '0px 5px 4px'}}>
          <CardTitle>Send private messages</CardTitle>
          <CardSubtitle>Want to talk to one user?</CardSubtitle>
          <CardText>Send a private message to other users!</CardText>
          
        </CardBody>
      </Card>
      <Card>
      
        <CardBody style={{boxShadow: '0px 5px 4px'}}>
          <CardTitle>Did we mention BugJabber is free?</CardTitle>
          <CardSubtitle>Yes, BugJabber is free for anyone!</CardSubtitle>
          <CardText >Tell your friends about us! We will never charge!</CardText>
          
        </CardBody>
      </Card>
    </div>
    <Modal isOpen={this.state.modal} toggle={this.toggle} className={this.props.className} style={{boxShadow: '0px 5px 4px'}}>
<ModalHeader toggle={this.toggle}>Sign up!</ModalHeader>

<ModalBody>
<Register/>


</ModalBody>
<ModalFooter>
</ModalFooter>

</Modal>

   </React.Fragment>
    
    );
  }
}

export default Main;
