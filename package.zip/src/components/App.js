import React from "react";
import { Grid } from "semantic-ui-react";
import "./App.css";
import { connect } from "react-redux";
import Messages from './Messages/Messages';
import Navbar from './Nav/navbar';



const App = ({ currentUser, currentChannel, isPrivateChannel, userPosts }) => (
  // <Grid columns="equal" className="app" style={{ background: "#eee" }}>

  //   <SidePanel key={currentUser && currentUser.uid} currentUser={currentUser} />
    
  //   <Grid.Column  style={{  paddingLeft: 300 }}>
  //     <Loads/>
  //   </Grid.Column>
  

  // </Grid>
  <React.Fragment>
  <Navbar key={currentUser && currentUser.uid} currentUser={currentUser}/>
  <Messages  key={currentChannel && currentChannel.id}
        currentChannel={currentChannel}
        currentUser={currentUser}
        isPrivateChannel={isPrivateChannel}/>
  </React.Fragment>
);

const mapStateToProps = state => ({
  currentUser: state.user.currentUser,
  currentChannel: state.channel.currentChannel,
  isPrivateChannel: state.channel.isPrivateChannel,
  userPosts: state.channel.userPosts
});

export default connect(mapStateToProps)(App);
