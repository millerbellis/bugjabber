 // Initialize Firebase
 import firebase from 'firebase/app';
 import "firebase/auth";
 import "firebase/database";
 import "firebase/storage";
 
 
 var config = {
    apiKey: "AIzaSyC69zoH8eItzfgmjF4uh07qDg9ITO7Dnzg",
    authDomain: "react-slack-clone-f5f74.firebaseapp.com",
    databaseURL: "https://react-slack-clone-f5f74.firebaseio.com",
    projectId: "react-slack-clone-f5f74",
    storageBucket: "react-slack-clone-f5f74.appspot.com",
    messagingSenderId: "443416217504"
  };
  firebase.initializeApp(config);

  export default firebase;